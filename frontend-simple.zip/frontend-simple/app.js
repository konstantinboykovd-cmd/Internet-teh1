﻿//  API клиент 
class ApiClient {
    constructor(baseURL) {
        this.baseURL = baseURL;
    }
    getToken() { return localStorage.getItem('access_token'); }
    async request(endpoint, options = {}) {
        const headers = { 'Content-Type': 'application/json' };
        const token = this.getToken();
        if (token) headers['Authorization'] = `Bearer ${token}`;
        const res = await fetch(`${this.baseURL}${endpoint}`, { ...options, headers });
        if (!res.ok) throw new Error(await res.text());
        if (res.status === 204) return null;
        return res.json();
    }
    get(url) { return this.request(url); }
    post(url, data) { return this.request(url, { method: 'POST', body: JSON.stringify(data) }); }
    put(url, data) { return this.request(url, { method: 'PUT', body: JSON.stringify(data) }); }
    delete(url) { return this.request(url, { method: 'DELETE' }); }
}
const api = new ApiClient('http://localhost:8000/api/v1');

//  UI утилиты 
function showToast(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i><span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showConfirm(title, message, onConfirm) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
        <div class="modal-container">
            <div class="modal-header">${escapeHtml(title)}</div>
            <div class="modal-body">${escapeHtml(message)}</div>
            <div class="modal-footer">
                <button class="btn-cancel">Отмена</button>
                <button class="btn-confirm">Подтвердить</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);
    const confirmBtn = overlay.querySelector('.btn-confirm');
    const cancelBtn = overlay.querySelector('.btn-cancel');
    const close = () => overlay.remove();
    confirmBtn.onclick = () => { onConfirm(); close(); };
    cancelBtn.onclick = close;
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : m === '<' ? '&lt;' : '&gt;');
}

// Роутер 
class Router {
    constructor() {
        window.addEventListener('hashchange', () => this.navigate());
        window.addEventListener('load', () => this.navigate());
    }
    navigate() {
        const hash = window.location.hash.slice(1) || '/';
        if (hash === '/sign-in') AuthPage.render();
        else if (hash === '/sign-up') RegisterPage.render();
        else if (hash === '/dashboard') DashboardPage.render();
        else if (hash === '/projects') ProjectsPage.render();
        else if (hash.startsWith('/project/')) ProjectDetailPage.render(hash.split('/')[2]);
        else if (hash === '/pipelines') PipelinesPage.render();
        else if (hash === '/analytics') AnalyticsPage.render();
        else if (hash === '/environments') EnvironmentsPage.render();
        else AuthPage.render();
    }
}

//  Базовый класс 
class Page {
    static setHtml(html) { document.getElementById('app').innerHTML = html; }
}

function renderNavbar() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return `
        <div class="navbar">
            <div class="nav-links">
                <a href="#/dashboard"><i class="fas fa-tachometer-alt"></i> Дашборд</a>
                <a href="#/projects"><i class="fas fa-folder"></i> Проекты</a>
                <a href="#/pipelines"><i class="fas fa-code-branch"></i> Pipelines</a>
                <a href="#/environments"><i class="fas fa-cloud-upload-alt"></i> Окружения</a>
                <a href="#/analytics"><i class="fas fa-chart-line"></i> Аналитика</a>
            </div>
            <div style="display: flex; align-items: center; gap: 1rem;">
                <span><i class="fas fa-user-circle"></i> ${escapeHtml(user.login || 'User')}</span>
                <button class="logout-btn" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Выйти</button>
            </div>
        </div>
    `;
}

//  Страница входа 
class AuthPage extends Page {
    static render() {
        this.setHtml(`
            <div class="auth-card">
                <div class="logo-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                <div class="auth-title">DevOps Platform</div>
                <div class="auth-subtitle">Войдите в свой аккаунт</div>
                <div class="input-group"><label>Логин или email</label><div class="input-field"><i class="fas fa-user"></i><input type="text" id="login" placeholder="Ваш логин или email"></div></div>
                <div class="input-group"><label>Пароль</label><div class="input-field"><i class="fas fa-lock"></i><input type="password" id="password" placeholder="••••••••"></div></div>
                <button class="btn-primary" id="loginBtn"><i class="fas fa-sign-in-alt"></i> Войти</button>
                <div id="errorMsg" class="error-message"></div>
                <div class="auth-footer">Нет аккаунта? <a href="#/sign-up">Зарегистрироваться</a></div>
            </div>
        `);
        document.getElementById('loginBtn').onclick = async () => {
            const login = document.getElementById('login').value;
            const password = document.getElementById('password').value;
            try {
                const data = await api.post(`/auth/login?login=${login}&password=${password}`);
                localStorage.setItem('access_token', data.access_token);
                const user = await api.get('/auth/me');
                localStorage.setItem('user', JSON.stringify(user));
                window.location.hash = '/dashboard';
                showToast('Вход выполнен', 'success');
            } catch (err) {
                document.getElementById('errorMsg').innerText = err.message;
                showToast(err.message, 'error');
            }
        };
    }
}

//  Регистрация 
class RegisterPage extends Page {
    static render() {
        this.setHtml(`
            <div class="auth-card">
                <div class="logo-icon"><i class="fas fa-user-plus"></i></div>
                <div class="auth-title">Регистрация</div>
                <div class="auth-subtitle">Создайте новый аккаунт</div>
                <div class="input-group"><label>Логин</label><div class="input-field"><i class="fas fa-at"></i><input type="text" id="login" placeholder="Придумайте логин"></div></div>
                <div class="input-group"><label>Email</label><div class="input-field"><i class="fas fa-envelope"></i><input type="email" id="email" placeholder="example@domain.com"></div></div>
                <div class="input-group"><label>Пароль</label><div class="input-field"><i class="fas fa-key"></i><input type="password" id="password" placeholder="Минимум 6 символов"></div></div>
                <button class="btn-primary" id="registerBtn"><i class="fas fa-check-circle"></i> Зарегистрироваться</button>
                <div id="errorMsg" class="error-message"></div>
                <div class="auth-footer">Уже есть аккаунт? <a href="#/sign-in">Войти</a></div>
            </div>
        `);
        document.getElementById('registerBtn').onclick = async () => {
            const login = document.getElementById('login').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            try {
                await api.post('/auth/register', { login, email, password });
                showToast('Регистрация успешна', 'success');
                window.location.hash = '/sign-in';
            } catch (err) {
                document.getElementById('errorMsg').innerText = err.message;
                showToast(err.message, 'error');
            }
        };
    }
}

//  Дашборд (визуализация данных health + график) 
class DashboardPage extends Page {
    static async render() {
        let health = '', metrics = null;
        try {
            const h = await api.get('/monitoring/health');
            health = JSON.stringify(h, null, 2);
            metrics = await api.get('/monitoring/metrics');
        } catch (e) { showToast('Ошибка загрузки метрик', 'error'); }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <h2><i class="fas fa-chart-line"></i> Мониторинг</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
                    <div><h3>Health</h3><pre>${health}</pre></div>
                    <div><h3>Метрики системы</h3><canvas id="metricsChart" width="400" height="200"></canvas></div>
                </div>
            </div>
        `);
        if (metrics) {
            new Chart(document.getElementById('metricsChart'), {
                type: 'bar',
                data: {
                    labels: ['CPU %', 'Memory %'],
                    datasets: [{
                        label: 'Загрузка',
                        data: [metrics.cpu_usage_percent, metrics.memory_usage_percent],
                        backgroundColor: ['#4f46e5', '#10b981']
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
    }
}

//  Проекты (CRUD) 
class ProjectsPage extends Page {
    static async render() {
        let projects = [];
        try { projects = await api.get('/projects/'); } catch (e) { showToast('Ошибка загрузки проектов', 'error'); }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <div style="display: flex; justify-content: space-between;"><h2><i class="fas fa-project-diagram"></i> Мои проекты</h2><button class="btn-primary" id="newProjectBtn"><i class="fas fa-plus"></i> Создать</button></div>
                <div class="grid-projects" id="projectsGrid"></div>
            </div>
        `);
        const grid = document.getElementById('projectsGrid');
        if (projects.length === 0) grid.innerHTML = '<p>Нет проектов. Создайте первый.</p>';
        for (const p of projects) {
            const filesCount = await api.get(`/projects/${p.id}/files/`).then(f => f.length).catch(() => 0);
            const pipelinesCount = await api.get(`/pipelines/${p.id}/`).then(p => p.length).catch(() => 0);
            const card = document.createElement('div');
            card.className = 'project-card';
            card.innerHTML = `
                <div style="display: flex; justify-content: space-between;">
                    <h3><i class="fas fa-code-branch"></i> ${escapeHtml(p.name)}</h3>
                    <button class="btn-danger" onclick="window.deleteProject('${p.id}')">Удалить</button>
                </div>
                <p>${escapeHtml(p.description || 'Нет описания')}</p>
                <div><i class="fas fa-file"></i> ${filesCount} файлов | <i class="fas fa-code-branch"></i> ${pipelinesCount} пайплайнов</div>
                <div style="font-size:0.7rem; color:#6b7280;">ID: ${escapeHtml(p.id)}</div>
                <button class="btn-primary" onclick="window.location.hash='/project/${p.id}'" style="margin-top:1rem;">Открыть</button>
            `;
            grid.appendChild(card);
        }
        document.getElementById('newProjectBtn').onclick = async () => {
            const name = prompt('Название проекта');
            if (name) { await api.post('/projects/', { name, repo_type: 'embedded' }); ProjectsPage.render(); showToast('Проект создан', 'success'); }
        };
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
        window.deleteProject = async (id) => {
            showConfirm('Удаление проекта', 'Удалить проект без возможности восстановления?', async () => {
                await api.delete(`/projects/${id}`);
                ProjectsPage.render();
                showToast('Проект удалён', 'success');
            });
        };
    }
}

//  Файлы проекта (с редактированием и загрузкой) 
class ProjectDetailPage extends Page {
    static async render(projectId) {
        let files = [];
        try { files = await api.get(`/projects/${projectId}/files/`); } catch (e) { showToast('Ошибка загрузки файлов', 'error'); }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
                    <h2><i class="fas fa-file-code"></i> Файлы проекта (ID: ${escapeHtml(projectId)})</h2>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn-primary" id="newFileBtn"><i class="fas fa-plus"></i> Новый файл</button>
                        <button class="btn-success" id="uploadFileBtn"><i class="fas fa-upload"></i> Загрузить файл</button>
                    </div>
                </div>
                <ul class="file-list" id="fileList"></ul>
            </div>
            <input type="file" id="fileInput" style="display: none;" />
            <div id="editFileModal" class="modal-overlay" style="display:none;">
                <div class="modal-container" style="max-width: 700px;">
                    <div class="modal-header">Редактирование файла</div>
                    <div class="modal-body">
                        <label>Путь: <span id="editFilePath"></span></label>
                        <textarea id="editFileContent" rows="15" style="width:100%; margin-top: 0.5rem; font-family: monospace;"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-confirm" id="saveFileBtn">Сохранить</button>
                        <button class="btn-cancel" id="cancelEditBtn">Отмена</button>
                    </div>
                </div>
            </div>
        `);
        const list = document.getElementById('fileList');
        if (files.length === 0) list.innerHTML = '<li>Нет файлов. Создайте первый.</li>';
        files.forEach(f => {
            const li = document.createElement('li');
            li.innerHTML = `<span><i class="fas fa-file"></i> ${escapeHtml(f.path)}</span>
                <div>
                    <button class="btn-primary" onclick="editFile('${projectId}', '${escapeHtml(f.path)}')">Редактировать</button>
                    <button class="btn-danger" onclick="deleteFile('${projectId}', '${escapeHtml(f.path)}')">Удалить</button>
                </div>`;
            list.appendChild(li);
        });

        window.editFile = async (pid, path) => {
            try {
                const file = await api.get(`/projects/${pid}/files/${encodeURIComponent(path)}`);
                const modal = document.getElementById('editFileModal');
                document.getElementById('editFilePath').innerText = path;
                document.getElementById('editFileContent').value = file.content || '';
                modal.style.display = 'flex';
                modal.dataset.pid = pid;
                modal.dataset.path = path;
            } catch (e) {
                showToast('Ошибка загрузки файла', 'error');
            }
        };

        const saveBtn = document.getElementById('saveFileBtn');
        const cancelBtn = document.getElementById('cancelEditBtn');
        const modal = document.getElementById('editFileModal');
        saveBtn.onclick = async () => {
            const pid = modal.dataset.pid;
            const path = modal.dataset.path;
            const newContent = document.getElementById('editFileContent').value;
            try {
                await api.put(`/projects/${pid}/files/${encodeURIComponent(path)}`, { content: newContent });
                showToast('Файл сохранён', 'success');
                modal.style.display = 'none';
                ProjectDetailPage.render(pid);
            } catch (e) {
                showToast('Ошибка сохранения: ' + e.message, 'error');
            }
        };
        cancelBtn.onclick = () => modal.style.display = 'none';
        modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };

        window.deleteFile = async (pid, path) => {
            showConfirm('Удалить файл', `Удалить ${path}?`, async () => {
                await api.delete(`/projects/${pid}/files/${encodeURIComponent(path)}`);
                ProjectDetailPage.render(pid);
                showToast('Файл удалён', 'success');
            });
        };

        document.getElementById('uploadFileBtn').onclick = () => {
            document.getElementById('fileInput').value = '';
            document.getElementById('fileInput').click();
        };
        document.getElementById('fileInput').onchange = async (event) => {
            const file = event.target.files[0];
            if (!file) return;
            let filePath = prompt('Введите путь к файлу (например, folder/script.py) или оставьте имя файла:', file.name);
            if (!filePath) filePath = file.name;
            const reader = new FileReader();
            reader.onload = async (e) => {
                const content = e.target.result;
                try {
                    await api.put(`/projects/${projectId}/files/${encodeURIComponent(filePath)}`, { content });
                    showToast(`Файл ${filePath} загружен`, 'success');
                    ProjectDetailPage.render(projectId);
                } catch (err) {
                    showToast('Ошибка загрузки: ' + err.message, 'error');
                }
            };
            reader.readAsText(file, 'UTF-8');
        };

        document.getElementById('newFileBtn').onclick = async () => {
            const path = prompt('Путь к файлу (например, README.md)');
            if (path) {
                const content = prompt('Содержимое') || '';
                await api.put(`/projects/${projectId}/files/${encodeURIComponent(path)}`, { content });
                ProjectDetailPage.render(projectId);
                showToast('Файл создан', 'success');
            }
        };
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
    }
}

// CI/CD пайплайны (с модальным окном и загрузкой YAML) 
class PipelinesPage extends Page {
    static async render() {
        let projects = [];
        try { projects = await api.get('/projects/'); } catch (e) { showToast('Ошибка загрузки проектов', 'error'); }
        let allPipelines = [];
        for (const proj of projects) {
            try { const pipelines = await api.get(`/pipelines/${proj.id}/`); allPipelines.push(...pipelines.map(p => ({ ...p, projectName: proj.name, projectId: proj.id }))); } catch (e) { }
        }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <div style="display: flex; justify-content: space-between;"><h2><i class="fas fa-code-branch"></i> CI/CD Pipelines</h2><button class="btn-primary" id="createPipelineBtn">Создать pipeline</button></div>
                <div id="pipelinesList"></div>
            </div>
            <div id="buildLogsModal" class="modal-overlay" style="display:none;"><div class="modal-container"><h3>Логи сборки</h3><pre id="logsContent" style="max-height:400px; overflow:auto;"></pre><button class="btn-primary" id="closeModalBtn">Закрыть</button></div></div>
            <div id="createPipelineModal" class="modal-overlay" style="display:none;">
                <div class="modal-container" style="max-width: 700px;">
                    <div class="modal-header">Создание пайплайна</div>
                    <div class="modal-body">
                        <div style="margin-bottom: 1rem;"><label>ID проекта:</label><input type="text" id="pipeProjectId" placeholder="Введите ID проекта" style="width:100%; padding:0.5rem;"></div>
                        <div style="margin-bottom: 1rem;"><label>Название пайплайна:</label><input type="text" id="pipeName" placeholder="Название" style="width:100%; padding:0.5rem;"></div>
                        <div style="margin-bottom: 1rem;"><label>YAML конфигурация:</label><textarea id="pipeYaml" rows="10" style="width:100%; font-family: monospace;" placeholder="steps:&#10;  - echo 'Hello'"></textarea>
                        <div style="margin-top: 0.5rem;"><button id="uploadYamlBtn" class="btn-success" style="padding: 0.3rem 0.8rem;"><i class="fas fa-upload"></i> Загрузить YAML файл</button></div></div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-confirm" id="confirmCreatePipeline">Создать</button>
                        <button class="btn-cancel" id="cancelCreatePipeline">Отмена</button>
                    </div>
                </div>
            </div>
            <input type="file" id="yamlFileInput" accept=".yaml,.yml" style="display: none;" />
        `);
        const container = document.getElementById('pipelinesList');
        if (allPipelines.length === 0) container.innerHTML = '<p>Нет пайплайнов. Создайте первый.</p>';
        for (const p of allPipelines) {
            const div = document.createElement('div');
            div.className = 'pipeline-card';
            div.innerHTML = `<div class="pipeline-header"><strong>${escapeHtml(p.name)}</strong><span>Проект: ${escapeHtml(p.projectName)} (ID: ${escapeHtml(p.projectId)})</span><button class="btn-success runPipelineBtn" data-id="${p.id}">Запустить сборку</button></div><div id="builds-${p.id}"></div>`;
            container.appendChild(div);
            await this.loadBuilds(p.id, div.querySelector(`#builds-${p.id}`));
        }

        const modal = document.getElementById('createPipelineModal');
        document.getElementById('createPipelineBtn').onclick = () => {
            document.getElementById('pipeProjectId').value = '';
            document.getElementById('pipeName').value = '';
            document.getElementById('pipeYaml').value = 'steps:\n  - echo "Build step"';
            modal.style.display = 'flex';
        };
        document.getElementById('cancelCreatePipeline').onclick = () => modal.style.display = 'none';
        modal.onclick = (e) => { if (e.target === modal) modal.style.display = 'none'; };

        document.getElementById('uploadYamlBtn').onclick = () => document.getElementById('yamlFileInput').click();
        document.getElementById('yamlFileInput').onchange = async (event) => {
            const file = event.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (e) => {
                document.getElementById('pipeYaml').value = e.target.result;
                showToast(`Файл ${file.name} загружен`, 'success');
            };
            reader.readAsText(file, 'UTF-8');
        };

        document.getElementById('confirmCreatePipeline').onclick = async () => {
            const projectId = document.getElementById('pipeProjectId').value.trim();
            const name = document.getElementById('pipeName').value.trim();
            const yaml = document.getElementById('pipeYaml').value;
            if (!projectId || !name) { showToast('Заполните ID проекта и название', 'error'); return; }
            try {
                await api.post(`/pipelines/${projectId}/`, { name, config_yaml: yaml });
                showToast('Пайплайн создан', 'success');
                modal.style.display = 'none';
                PipelinesPage.render();
            } catch (err) { showToast('Ошибка: ' + err.message, 'error'); }
        };

        document.querySelectorAll('.runPipelineBtn').forEach(btn => {
            btn.onclick = async (e) => {
                const pipelineId = btn.dataset.id;
                try {
                    const build = await api.post(`/pipelines/${pipelineId}/run`);
                    showToast(`Сборка запущена, ID: ${build.id}`, 'success');
                    PipelinesPage.render();
                } catch (err) { showToast('Ошибка запуска: ' + err.message, 'error'); }
            };
        });
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
        window.showLogs = (logs) => {
            const modalLogs = document.getElementById('buildLogsModal');
            document.getElementById('logsContent').innerText = logs;
            modalLogs.style.display = 'flex';
            document.getElementById('closeModalBtn').onclick = () => modalLogs.style.display = 'none';
        };
    }
    static async loadBuilds(pipelineId, container) {
        try {
            const builds = await api.get(`/pipelines/${pipelineId}/builds/`);
            if (!builds.length) { container.innerHTML = '<em>Нет сборок</em>'; return; }
            let html = '<ul>';
            for (const b of builds) {
                const statusClass = b.status === 'success' ? 'status-success' : b.status === 'failed' ? 'status-failed' : 'status-running';
                html += `<li style="display:flex; justify-content:space-between;">Сборка от ${new Date(b.created_at).toLocaleString()} <span class="pipeline-status ${statusClass}">${b.status}</span> <button class="btn-primary" onclick="viewBuildLogs('${b.id}')">Логи</button></li>`;
            }
            html += '</ul>';
            container.innerHTML = html;
            window.viewBuildLogs = async (buildId) => {
                try { const logsData = await api.get(`/pipelines/builds/${buildId}/logs`); window.showLogs(logsData.logs || 'Логов нет'); } catch (e) { showToast('Ошибка загрузки логов', 'error'); }
            };
        } catch (e) { container.innerHTML = '<em>Ошибка загрузки сборок</em>'; }
    }
}

// ---------- Окружения (деплой) ----------
class EnvironmentsPage extends Page {
    static async render() {
        let allBuilds = [], deployments = [];
        try {
            const projects = await api.get('/projects/');
            for (const proj of projects) {
                const pipelines = await api.get(`/pipelines/${proj.id}/`);
                for (const pipe of pipelines) {
                    const builds = await api.get(`/pipelines/${pipe.id}/builds/`);
                    const successful = builds.filter(b => b.status === 'success');
                    allBuilds.push(...successful.map(b => ({ ...b, projectName: proj.name, projectId: proj.id, pipelineName: pipe.name })));
                }
            }
            deployments = await api.get('/deployments/');
        } catch (e) { showToast('Ошибка загрузки данных', 'error'); }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <h2><i class="fas fa-cloud-upload-alt"></i> Деплой на окружения</h2>
                <div><h3>Успешные сборки</h3><div id="buildsList"></div></div>
                <div style="margin-top:2rem;"><h3>История деплоев</h3><div id="deploymentsList"></div></div>
            </div>
            <div id="deployLogsModal" class="modal-overlay" style="display:none;"><div class="modal-container"><h3>Логи деплоя</h3><pre id="deployLogsContent"></pre><button class="btn-primary" id="closeDeployModalBtn">Закрыть</button></div></div>
        `);
        const buildsDiv = document.getElementById('buildsList');
        if (allBuilds.length === 0) buildsDiv.innerHTML = '<p>Нет успешных сборок. Запустите сборку и дождитесь успеха.</p>';
        else {
            const ul = document.createElement('ul'); ul.className = 'file-list';
            allBuilds.forEach(b => {
                const li = document.createElement('li');
                li.innerHTML = `<span><strong>${escapeHtml(b.projectName)}</strong> (${escapeHtml(b.projectId)}) / ${escapeHtml(b.pipelineName)} / сборка ${b.id} (${new Date(b.created_at).toLocaleString()})</span>
                    <div><button class="btn-success" onclick="deployTo('${b.id}', 'stage')">Деплой на stage</button><button class="btn-warning" onclick="deployTo('${b.id}', 'prod')">Деплой на prod</button></div>`;
                ul.appendChild(li);
            });
            buildsDiv.appendChild(ul);
        }
        const deploysDiv = document.getElementById('deploymentsList');
        if (deployments.length === 0) deploysDiv.innerHTML = '<p>Нет деплоев.</p>';
        else {
            const ul = document.createElement('ul'); ul.className = 'file-list';
            deployments.forEach(d => {
                const statusClass = d.status === 'success' ? 'deployment-success' : d.status === 'failed' ? 'deployment-failed' : 'deployment-pending';
                const li = document.createElement('li');
                li.innerHTML = `<span>Сборка ${d.build_id} → ${d.environment} | Статус: <span class="deployment-status ${statusClass}">${d.status}</span> | ${new Date(d.created_at).toLocaleString()}</span>
                    <div><button class="btn-primary" onclick="redeploy('${d.build_id}', '${d.environment}')">Повторить деплой</button><button class="btn-warning" onclick="rollbackDeployment('${d.build_id}', '${d.environment}')">Откатить</button><button class="btn-primary" onclick="viewDeployLogs('${d.id}')">Логи</button></div>`;
                ul.appendChild(li);
            });
            deploysDiv.appendChild(ul);
        }
        window.deployTo = async (buildId, env) => {
            try { const deploy = await api.post('/deployments/', { build_id: buildId, environment: env }); showToast(`Деплой на ${env} запущен, ID: ${deploy.id}`, 'success'); EnvironmentsPage.render(); } catch (err) { showToast('Ошибка: ' + err.message, 'error'); }
        };
        window.redeploy = async (buildId, env) => {
            showConfirm('Повторный деплой', `Развернуть сборку ${buildId} на ${env}?`, async () => {
                const deploy = await api.post('/deployments/', { build_id: buildId, environment: env });
                showToast(`Деплой повторно запущен, ID: ${deploy.id}`, 'success');
                EnvironmentsPage.render();
            });
        };
        window.rollbackDeployment = async (buildId, currentEnv) => {
            const targetEnv = currentEnv === 'stage' ? 'prod' : 'stage';
            showConfirm('Откат', `Развернуть сборку ${buildId} на ${targetEnv}?`, async () => {
                const deploy = await api.post('/deployments/', { build_id: buildId, environment: targetEnv });
                showToast(`Деплой на ${targetEnv} запущен, ID: ${deploy.id}`, 'success');
                EnvironmentsPage.render();
            });
        };
        window.viewDeployLogs = async (deployId) => {
            try { const logs = await api.get(`/deployments/${deployId}/logs`); document.getElementById('deployLogsContent').innerText = logs.logs || 'Логов нет'; document.getElementById('deployLogsModal').style.display = 'flex'; document.getElementById('closeDeployModalBtn').onclick = () => document.getElementById('deployLogsModal').style.display = 'none'; } catch (e) { showToast('Ошибка загрузки логов', 'error'); }
        };
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
    }
}

//Аналитика (процент успешных сборок, статистика, экспорт Excel) 
class AnalyticsPage extends Page {
    static async render() {
        let successRate = 0, stats = {};
        try {
            const rate = await api.get('/analytics/builds/success-rate?days=30');
            successRate = rate.success_rate;
            stats = await api.get('/analytics/builds/stats');
        } catch (e) { showToast('Ошибка загрузки аналитики', 'error'); }
        this.setHtml(`
            ${renderNavbar()}
            <div class="dashboard-card">
                <h2><i class="fas fa-chart-pie"></i> Аналитика сборок</h2>
                <div style="display: grid; grid-template-columns: repeat(2,1fr); gap:1rem;">
                    <div><strong>Процент успешных сборок (30 дней):</strong> ${successRate}%</div>
                    <div><strong>Всего сборок:</strong> ${stats.total_builds || 0}</div>
                    <div><strong>Успешных:</strong> ${stats.successful_builds || 0}</div>
                    <div><strong>Неудачных:</strong> ${stats.failed_builds || 0}</div>
                    <div><strong>Средняя длительность (сек):</strong> ${stats.average_duration_seconds || '—'}</div>
                </div>
                <button class="btn-primary" id="exportExcelBtn" style="margin-top:1rem;"><i class="fas fa-file-excel"></i> Экспорт логов (Excel)</button>
            </div>
        `);
        document.getElementById('exportExcelBtn').onclick = async () => {
            const buildId = prompt('Введите ID сборки для экспорта логов:');
            if (buildId) {
                try {
                    const res = await fetch(`http://localhost:8000/api/v1/pipelines/builds/${buildId}/export`, {
                        headers: { 'Authorization': `Bearer ${api.getToken()}` }
                    });
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `build_${buildId}_logs.xlsx`;
                    a.click();
                    URL.revokeObjectURL(url);
                    showToast('Логи экспортированы в Excel', 'success');
                } catch (e) {
                    showToast('Ошибка экспорта: ' + e.message, 'error');
                }
            }
        };
        document.getElementById('logoutBtn').onclick = () => { localStorage.clear(); window.location.hash = '/sign-in'; showToast('Выход выполнен', 'success'); };
    }
}

// Запуск
new Router();